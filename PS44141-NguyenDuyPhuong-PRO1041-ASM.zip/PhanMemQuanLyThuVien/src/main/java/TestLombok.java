import lombok.Data;

@Data
public class TestLombok {
    private String name;
    private int age;
}
